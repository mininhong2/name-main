package edu.dwacademy.cardatabase;

import java.util.Arrays;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

import edu.dwacademy.cardatabase.domain.AppUser;
import edu.dwacademy.cardatabase.domain.AppUserRepository;
import edu.dwacademy.cardatabase.domain.Car;
import edu.dwacademy.cardatabase.domain.CarRepository;
import edu.dwacademy.cardatabase.domain.Owner;
import edu.dwacademy.cardatabase.domain.OwnerRepository;

@SpringBootApplication
public class CardatabaseApplication implements CommandLineRunner {
	private static final Logger logger = LoggerFactory.getLogger(
			CardatabaseApplication.class);

	private final CarRepository repository;
	private final OwnerRepository orepository;
	private final AppUserRepository urepository;
	public CardatabaseApplication(CarRepository repository,
			                      OwnerRepository orepository,
			                      AppUserRepository urepository) {
		this.repository = repository;
		this.orepository = orepository;
		this.urepository = urepository;
	}
	public static void main(String[] args) {
		SpringApplication.run(CardatabaseApplication.class, args);
		logger.info("Application started");
	}

	@Override
	public void run(String... args) throws Exception {
		Owner owner1 = new Owner("John" , "Johnson");
	    Owner owner2 = new Owner("Mary" , "Robinson");
	    Owner owner3 = new Owner("Qary" , "Witen");
	    Owner owner4 = new Owner("Farton" , "Horon");
	    Owner owner5 = new Owner("edson" , "Geon");
	    orepository.saveAll(Arrays.asList(owner1, owner2,owner3,owner4,owner5));
		repository.save(new Car("cleaning1", "", "","","","", 2024,  owner1));
		repository.save(new Car("cleaning2", "", "","","","", 2024,  owner1));
		repository.save(new Car("cleaning3", "", "","","","", 2024, owner1));
		repository.save(new Car("cleaning4", "", "","","","", 2024,  owner1));
		
      repository.save(new Car("feeding1", "", "","","","", 2024, owner2));
      repository.save(new Car("feeding2", "", "","","","", 2024, owner2));
      repository.save(new Car("feeding3", "", "","","","", 2024, owner2));
      repository.save(new Car("feeding4", "", "","","","", 2024, owner2));
      
      
      repository.save(new Car("guiding1", "","","","","",2024, owner3));
      repository.save(new Car("guiding2", "","","","","", 2024, owner3));
      repository.save(new Car("guiding3", "", "","","","", 2024, owner3));
      repository.save(new Car("guiding4", "", "","","","", 2024, owner3));
      
      
      repository.save(new Car("medical1", "","","","","", 2024, owner4));
      repository.save(new Car("medical2", "","","","","", 2024, owner4));
      repository.save(new Car("medical3", "","","","","", 2024, owner4));
      repository.save(new Car("medical4", "","","","","", 2024, owner4));
      
      repository.save(new Car("security1", "", "","","","", 2024, owner5));
      repository.save(new Car("security2", "", "","","","", 2024, owner5));
      repository.save(new Car("security3", "", "","","","", 2024, owner5));
      repository.save(new Car("security4", "", "","","","", 2024, owner5));
      
      // Fetch all cars and log to console
      for (Car car : repository.findAll()) {
          logger.info("brand: {}, model: {}",
              car.getDepartment(), car.getEmpname());
      }
      
   
      urepository.save(new AppUser("clean1","$2a$10$noihUyAt23/YpYdsJoqaAuMIpeeXImd6h9zCCjPn4juzNn9ZtVP/q","CLEAN1"));
      urepository.save(new AppUser("clean2","$2a$10$akZFf3Jsiji4W6EMlw8YgOozKMLyfrf0T.fcBoBfBCjUWgzt2OD72","CLEAN2"));
      urepository.save(new AppUser("clean3", "$2a$10$HycyjdbmnvanmvGoE..ntuudsxJob3fJ2oIKvGGjDImVAH.jP455e", "CLEAN3"));
      urepository.save(new AppUser("clean4", "$2a$10$hKp261ZMz363GTXz6aCokewN0dDmabEQJ3sr194DMs7Dq8qkvQs0i", "CLEAN4"));
      
      urepository.save(new AppUser("feed1","$2a$10$NOOX/B8gCNu9sBn8PKQs2e3Jm4Wak38R10bz38CRMMDSLYrmGKKRm","FEED1"));
      urepository.save(new AppUser("feed2","$2a$10$dic64zuzWfQqo5q.5ZL7VuboBUx4xe4BivuRve5u0MTTyxED4iqZi","FEED2"));
      urepository.save(new AppUser("feed3", "$2a$10$BsQtk4TmEGItA8HL0mxIXu/CV21n.x3tPs5Xcm0HJ1T8ObNBAjDVW", "FEED3"));
      urepository.save(new AppUser("feed4", "$2a$10$DSQjW8qMEfrbrGM1X8SIkul6pog1RUZLd9.SrZWptDXWOt90WM1Ry", "FEED4"));
      
      urepository.save(new AppUser("guide1","$2a$10$3EGdO9Rzlqh.jLYmQmwEPeGE8JP7J5vPXPjsvYECG.bXnqykBinsq","GUIDE1"));
      urepository.save(new AppUser("guide2","$2a$10$PsE3G4Fo.Os2t275zFY5ruzdwr4T3vkbEy.XYH.w6.23M3udzS/bm","GUIDE2"));
      urepository.save(new AppUser("guide3", "$2a$10$.dCAXSFWZoPwhJ/DeXrOBuoC/qxdik0gWNRzI4JpzAjfhMGmtvrF2", "GUIDE3"));
      urepository.save(new AppUser("guide4", "$2a$10$1pYfBSxHRsBQwqnMzmROKeieeMJmV0j9AufcFQDEMjdrRUS73dqva", "GUIDE4"));
      
      urepository.save(new AppUser("medical1","$2a$10$w1W/vZQZoGhJcVtx.EsxOezuSgOqj4.vXo/UAcWgGi7SS6xjYSUiy","MEDICAL1"));
      urepository.save(new AppUser("medical2","$2a$10$p4tsGUV2f0CDixz1aKtnbeRTcEAAYWXe8DcVRBmiM/fjeD.OX18I6","MEDICAL2"));
      urepository.save(new AppUser("medical3", "$2a$10$sABkdxd3wK9WnD3N5wF2uuiJ45i.EAwndrx1v0xyNSAxCuyRPU8gi", "MEDICAL3"));
      urepository.save(new AppUser("medical4", "$2a$10$HJVWQkbbNiJ5y2.hc56jH.dgfa6XKUCJlLtYhmfgZ.yDeEo/lM5Ee", "MEDICAL4"));
      
      urepository.save(new AppUser("security1","$2a$10$Q/eW9BRo/mzkgBGgagZCD.Azw7wogK0A6155a4C.BlQd4AtT1RfdK","SECURITY1"));
      urepository.save(new AppUser("security2","$2a$10$CQoHdUOxwrWRxUyDhuH15egF3e/P7.lJc7pCoKXqTt/FxUkajdbKu","SECURITY2"));
      urepository.save(new AppUser("security3", "$2a$10$kPia.fN7dGuZb3p4DtfFbOCxPiXyvsY.MR0oQc0QAqGvb7yeMCXjS", "SECURITY3"));
      urepository.save(new AppUser("security4", "$2a$10$Lc2T/4GFaccpx8UT0yKusuK7wDc1lAzXaXX2ju3EDLxr7FePfWcE.", "SECURITY4"));
      
      
		
	}

}
