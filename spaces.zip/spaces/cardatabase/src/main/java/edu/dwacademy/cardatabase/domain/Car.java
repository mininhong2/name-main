package edu.dwacademy.cardatabase.domain;

import jakarta.persistence.Entity;
import jakarta.persistence.FetchType;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;

@Entity
public class Car {
	@Id
    @GeneratedValue(strategy=GenerationType.AUTO)
    private Long id;
    private String department, empname, worklog, position, email, pnumber;
    
    private int listYear;
    @ManyToOne(fetch=FetchType.LAZY)
    @JoinColumn(name="owner")
    private Owner owner;
    // Getter and setter
    public Owner getOwner() {
        return owner;
    }
    public void setOwner(Owner owner) {
        this.owner = owner;
    }
    
    public Car() {
    }
    public Car(String department, String empname, String worklog, String position, String email, String pnumber,
         int listYear, 
        Owner owner) {
            super();
            this.department = department;
            this.empname = empname;
            this.worklog = worklog;
            this.position = position;
            this.email = email;
            this.pnumber = pnumber;
            
            this.listYear = listYear;
            
            this.owner = owner;
    }
	public Long getId() {
		return id;
	}
	public void setId(Long id) {
		this.id = id;
	}
	
	public String getPosition() {
		return position;
	}
	public void setPosition(String position) {
		this.position = position;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public String getPnumber() {
		return pnumber;
	}
	public void setPnumber(String pnumber) {
		this.pnumber = pnumber;
	}
	public String getEmpname() {
		return empname;
	}
	public void setEmpname(String empname) {
		this.empname = empname;
	}
	public String getWorklog() {
		return worklog;
	}
	public void setWorklog(String worklog) {
		this.worklog = worklog;
	}
	public String getDepartment() {
		return department;
	}
	public void setDepartment(String department) {
		this.department = department;
	}
	
	public int getListYear() {
		return listYear;
	}
	public void setListYear(int listYear) {
		this.listYear = listYear;
	}

	
    
    
}
