package edu.dwacademy.cardatabase.domain;

public record AccountCredentials(String username, String password) {

}
