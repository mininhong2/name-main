package teampro.projects;

import java.util.HashMap;
import java.util.Scanner;

public class EmployeeManagementSystem {
	private static HashMap<String, Employee> employees = new HashMap<>();

	public static void main(String[] args) {
		Scanner scanner = new Scanner(System.in);

		while (true) {
			System.out.println("\n직원 정보 관리 시스템");
			System.out.println("1. 직원 추가");
			System.out.println("2. 직원 수정");
			System.out.println("3. 직원 조회");
			System.out.println("4. 직원 삭제");
			System.out.println("5. 모든 직원 조회");
			System.out.println("6. 직원 월급 조회");
			System.out.println("7.이메일 전송");
			System.out.println("8. 종료");
			System.out.print("원하는 작업의 번호를 입력하세요: ");
			int choice = scanner.nextInt();
			scanner.nextLine(); // 입력 버퍼 지우기

			switch (choice) {
			case 1:
				addEmployee(scanner);
				break;
			case 2:
				updateEmployee(scanner);
				break;
			case 3:
				viewEmployee(scanner);
				break;
			case 4:
				deleteEmployee(scanner);
				break;
			case 5:
				viewAllEmployees();
				break;
			case 6:
				calculateEachEmployeeSalary(scanner);
				break;
			case 7:
				sandEmail(scanner);
				break;
			case 8:
				System.out.println("시스템을 종료합니다.");
				scanner.close();
				return;
			default:
				System.out.println("잘못된 입력입니다. 다시 시도해주세요.");
			}
		}
	}

	private static void addEmployee(Scanner scanner) {
		System.out.print("이름: ");
		String name = scanner.nextLine();
		System.out.print("시간당 급여: ");
		double hourlyWage = scanner.nextDouble();
		System.out.print("근무 시간: ");
		int hoursWorked = scanner.nextInt();
		scanner.nextLine(); // 입력 버퍼 지우기
		System.out.print("이메일: ");
		String email = scanner.nextLine();
		Employee employee = new Employee(name, hourlyWage, hoursWorked, email);
		employees.put(name, employee);
		System.out.println(name + " 직원이 추가되었습니다.");
	}

	private static void updateEmployee(Scanner scanner) {
		System.out.print("수정할 직원의 이름을 입력하세요: ");
		String name = scanner.nextLine();
		if (employees.containsKey(name)) {
			System.out.print("시간당 급여: ");
			double hourlyWage = scanner.nextDouble();
			System.out.print("근무 시간: ");
			int hoursWorked = scanner.nextInt();
			scanner.nextLine();
			System.out.print("이메일: ");
			String email = scanner.nextLine();
			Employee employee = employees.get(name);
			employee.setHourlyWage(hourlyWage);
			employee.setHoursWorked(hoursWorked);
			employee.setEmail(email);
			System.out.println(name + " 직원 정보가 수정되었습니다.");
		} else {
			System.out.println(name + " 직원을 찾을 수 없습니다.");
		}
	}

	private static void viewEmployee(Scanner scanner) {
		System.out.print("조회할 직원의 이름을 입력하세요: ");
		String name = scanner.nextLine();
		if (employees.containsKey(name)) {
			Employee employee = employees.get(name);
			System.out.println("이름: " + employee.getName() + ", 시간당 급여: " + employee.getHourlyWage() + ", 근무 시간: "
					+ employee.getHoursWorked() + ", 이메일: " + employee.getEmail());
		} else {
			System.out.println(name + " 직원을 찾을 수 없습니다.");
		}
	}

	private static void deleteEmployee(Scanner scanner) {
		System.out.print("삭제할 직원의 이름을 입력하세요: ");
		String name = scanner.nextLine();
		if (employees.containsKey(name)) {
			employees.remove(name);
			System.out.println(name + " 직원이 삭제되었습니다.");
		} else {
			System.out.println(name + " 직원을 찾을 수 없습니다.");
		}
	}

	private static void calculateEachEmployeeSalary(Scanner scanner) {
		System.out.print("조회할 직원의 이름을 입력하세요: ");
		String name = scanner.nextLine();
		final int WORK_HOURS_PER_MONTH = 240;
		if (employees.containsKey(name)) {
			Employee employee = employees.get(name);
			double monthlySalary = employee.getHourlyWage() * WORK_HOURS_PER_MONTH;
			System.out.println("이름: " + employee.getName() + ", 시간당 급여: " + employee.getHourlyWage() + ", 근무 시간: "
					+ employee.getHoursWorked() + ", 이메일: " + employee.getEmail() + ", 월급: " + monthlySalary);
		} else {
			System.out.println(name + " 직원을 찾을 수 없습니다.");
		}

	}

	private static void viewAllEmployees() {
	           System.out.println("모든 직원의 정보:");
	           final int WORK_HOURS_PER_MONTH = 240;
	           
	           for (Employee employee : employees.values()) {
	        	   double monthlySalary = employee.getHourlyWage() *WORK_HOURS_PER_MONTH ;
	               System.out.println("이름: " + employee.getName() + ", 시간당 급여: " + employee.getHourlyWage() + ", "
	               		+ "근무 시간: " + employee.getHoursWorked() + ", 이메일: " + employee.getEmail() + ", 월급: " + monthlySalary) ;
	           }
	       }

	private static void sandEmail(Scanner scanner) {
		System.out.print("조회할 직원의 이름을 입력하세요: ");
		String name = scanner.nextLine();
		final int WORK_HOURS_PER_MONTH = 240;
	    	if (employees.containsKey(name)) {
	    		System.out.print("급여정보를 보낼 이메일을 입력해주세요 : ");
				String email = scanner.nextLine();
				Employee employee = employees.get(name);
				employee.setEmail(email);
				double monthlySalary = employee.getHourlyWage() * WORK_HOURS_PER_MONTH;
				System.out.println("이름: " + employee.getName() + ", 시간당 급여: " + employee.getHourlyWage() + ", 근무 시간: "
						+ employee.getHoursWorked() + ", 월급: " + monthlySalary);
				System.out.println(name + " 님 이메일로 전송되었습니다.");
			} else {
				System.out.println(name + " 직원을 찾을 수 없습니다.");
			}
	    	
	    	
	    }
}
