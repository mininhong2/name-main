package teampro.projects;

public class Employee {
	 private String name;
     private double hourlyWage;
     private int hoursWorked;
     private String email;

     // 생성자
     public Employee(String name, double hourlyWage, int hoursWorked, String email) {
         this.name = name;
         this.hourlyWage = hourlyWage;
         this.hoursWorked = hoursWorked;
         this.email = email;
     }

     public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	// getter 및 setter 메소드
     public String getName() {
         return name;
     }

     public void setName(String name) {
         this.name = name;
     }

     public double getHourlyWage() {
         return hourlyWage;
     }

     public void setHourlyWage(double hourlyWage) {
         this.hourlyWage = hourlyWage;
     }

     public int getHoursWorked() {
         return hoursWorked;
     }

     public void setHoursWorked(int hoursWorked) {
         this.hoursWorked = hoursWorked;
     }

}
