package com.examplecoffee.democoffee;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class DemocoffeeApplication {

	public static void main(String[] args) {
		SpringApplication.run(DemocoffeeApplication.class, args);
	}

}
