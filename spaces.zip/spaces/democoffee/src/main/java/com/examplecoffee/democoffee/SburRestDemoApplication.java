package com.examplecoffee.democoffee;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.ui.Model;

import java.util.UUID;
import java.util.ArrayList;
import java.util.List;

@SpringBootApplication
public class SburRestDemoApplication {

    public static void main(String[] args) {
        SpringApplication.run(SburRestDemoApplication.class, args);
    }

}

class Coffee {
    private final String id;
    private String name;

    public Coffee(String id, String name) {
        this.id = id;
        this.name = name;
    }

    public Coffee(String name) {
        this(UUID.randomUUID().toString(), name);
    }

    public String getId() {
        return id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }
}

@RestController
@RequestMapping("/")
class RestApiDemoController {
    private List<Coffee> coffees = new ArrayList<>();

    public RestApiDemoController() {
        initialize();
    }

    public void initialize() {
        coffees.addAll(List.of(new Coffee("Cafe Cereza"), new Coffee("Cafe Ganador"), new Coffee("Cafe Lareno"),
                new Coffee("Cafe Tres Pontas")));
    }

    @GetMapping("/coffees")
    String getCoffees(Model model) {
        model.addAttribute("coffees", coffees);
        return "CoffeeList";
    }
}