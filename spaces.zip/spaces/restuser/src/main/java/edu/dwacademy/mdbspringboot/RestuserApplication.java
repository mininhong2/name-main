package edu.dwacademy.mdbspringboot;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class RestuserApplication {

	public static void main(String[] args) {
		SpringApplication.run(RestuserApplication.class, args);
	}

}
