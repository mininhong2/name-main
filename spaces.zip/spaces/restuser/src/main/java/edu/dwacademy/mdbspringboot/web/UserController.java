package edu.dwacademy.mdbspringboot.web;

import java.util.Optional;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RestController;

import edu.dwacademy.mdbspringboot.model.User;
import edu.dwacademy.mdbspringboot.repository.UserRepository;

@RestController
public class UserController {
	
	private final UserRepository repository;
	public UserController(UserRepository repository) {
		this.repository =repository;
	}
	
	@GetMapping("/users/{name}")
	public Optional<User> getUser(@PathVariable String name) {
		Optional<User> user =  repository.findByName(name);
		return user;
	}
	

	@GetMapping("/users")
	public Iterable<User> getUsers() {
		Iterable<User> users =  repository.findAll();
		return users;
	}
}
