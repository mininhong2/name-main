package com.dwacademy.dwtest;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DwtestApplicationTests {

	@Test
	void contextLoads() {
	}

}
