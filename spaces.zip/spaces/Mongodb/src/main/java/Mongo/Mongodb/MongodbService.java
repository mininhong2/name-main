package Mongo.Mongodb;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class MongodbService {
private final MongodbRepository mongodbRepository;
    
    @Autowired
    public MongodbService(MongodbRepository mongodbRepository) {
        this.mongodbRepository = mongodbRepository;
    }

    public List<Mongo> getAllUsers() {
        return mongodbRepository.findAll();
    }

    public Mongo addUser(Mongo mongo) {
        return mongodbRepository.save(mongo);
    }

    public Mongo getUserById(String id) {
        return mongodbRepository.findById(id).orElseThrow(() -> new MongoNotFoundException(id));
    }

    public Mongo updateUser(String id, Mongo userdetails) {
        Mongo mongo = getUserById(id);

        mongo.setName(userdetails.getName());
        mongo.setEmail(userdetails.getEmail());
        mongo.setPassword(userdetails.getPassword());

        return mongodbRepository.save(mongo);
    }

    public void deleteUser(String id) {
        mongodbRepository.deleteById(id);
    }

}
