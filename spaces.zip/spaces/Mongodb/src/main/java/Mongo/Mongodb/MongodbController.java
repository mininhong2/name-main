package Mongo.Mongodb;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@CrossOrigin
@RestController
@RequestMapping("/api/users")
public class MongodbController {
	
	private final MongodbService mongodbService;

    @Autowired
    public MongodbController(MongodbService mongodbService) {
        this.mongodbService = mongodbService;
    }
    
    @GetMapping
    public List<Mongo> getAllUser() {
        return mongodbService.getAllUsers();
    }

    @GetMapping("/{id}")
    public Mongo getUserById(@PathVariable("id") String id) {
        return mongodbService.getUserById(id);
    }

    @PostMapping
    public Mongo addUser(@RequestBody Mongo mongo) {
        return mongodbService.addUser(mongo);
    }

    @PutMapping("/{id}")
    public Mongo updateUser(@PathVariable("id") String id, @RequestBody Mongo userdetails) {
        return mongodbService.updateUser(id, userdetails);
    }

    @DeleteMapping("/{id}")
    public void deleteUser(@PathVariable("id") String id) {
        mongodbService.deleteUser(id);
    }
	

}