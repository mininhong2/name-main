package Mongo.Mongodb;

public class MongoNotFoundException  extends RuntimeException {
	public MongoNotFoundException(String id) {
        super("User Not Found With Id " + id);
    }
}
