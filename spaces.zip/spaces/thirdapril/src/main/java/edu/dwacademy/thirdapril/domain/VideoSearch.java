package edu.dwacademy.thirdapril.domain;

public record VideoSearch(String name, String description) {

}
