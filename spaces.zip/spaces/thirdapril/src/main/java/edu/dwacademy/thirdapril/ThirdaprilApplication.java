package edu.dwacademy.thirdapril;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ThirdaprilApplication {

	public static void main(String[] args) {
		SpringApplication.run(ThirdaprilApplication.class, args);
	}

}
