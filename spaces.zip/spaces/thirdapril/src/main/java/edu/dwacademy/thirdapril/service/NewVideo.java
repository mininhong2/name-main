package edu.dwacademy.thirdapril.service;

public record NewVideo(String name, String description) {

}
