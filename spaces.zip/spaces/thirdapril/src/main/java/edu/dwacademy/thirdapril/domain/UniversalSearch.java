package edu.dwacademy.thirdapril.domain;

public record UniversalSearch(String value) {

}
