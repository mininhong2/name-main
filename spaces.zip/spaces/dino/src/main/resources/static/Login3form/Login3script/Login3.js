function showEmployeeLogin(){
    document.getElementById('loginForm').action = 'employee_login.php';
    document.getElementById('username').placeholder='직원 아이디를 입력하세요';
    document.getElementById('password').placeholder='직원 비밀번호를 입력하세요';

}
function showPersonalLogin(){
    document.getElementById('loginForm').action='personal_login.php';
    document.getElementById('username').placeholder=' 회원 아이디를 입력하세요';
    document.getElementById('password').placeholder='회원 비밀번호를 입력하세요';
}
 function validateForm(){
    var username = document.getElementById('username').value;
    var password = document.getElementById('password').value;
 
 if((username==='employee'&& password ==='employee123')||(username === 'member'&&password === 'member123')){
    return true;
 }else{
    document.getElementById('errorMessage').innerText='아이디 또는 비밀번호가 잘못되었습니다.';
    document.getElementById('errorMessage').style.display = 'block';
    return false;
 }
}