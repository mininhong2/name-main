function checkDuplicate(){
    var username = document.getElementById('username').value;
    var existingUsernames=['user1','user2','user3'];
    if(existingUsernames.includes(username)){
        document.getElementById('duplicateMessage').innerText='이미 가입된 아이디입니다.';

    }else{
        document.getElementById('duplicateMessage').innerText='사용 가능한 아이디입니다.';
        
    }
}
function checkPasswordMatch(){
    var password = document.getElementById('password').value;
    var confirmPassword = document.getElementById('confirmPassword').value;
    if(password !==confirmPassword){
        document.getElementById('passwordMatchMessage').innerText = '비밀번호가 일치하지 않습니다.';

    }else{
        document.getElementById('passwordMatchMessage').innerText = "";
    }
}
function checkEmail(){

}
function submitForm(){
    var username = document.getElementById('username').value;
    var name = document.getElementById('name').value;
    var gender = document.querySelector('input[name="gender"]:cheched').value;
    var address = document.getElementById('address').value;
    var phone = document.getElementById('phone').value;
    var email = document.getElementById('email').value;

    alert(name+'님 반갑습니다! Mesozoic Eden에 회원이 되신 것을 진심으로 축하합니다.');
    return false;
}
